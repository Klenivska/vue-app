const path = require("path");

module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
  productionSourceMap: false,
  // outputDir: path.resolve(__dirname, "../vue-expenses-api/wwwroot"),
  // assetsDir: "../../vue-expenses-api/wwwroot/static"
}