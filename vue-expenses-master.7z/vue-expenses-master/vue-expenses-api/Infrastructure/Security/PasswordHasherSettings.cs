namespace vue_expenses_api.Infrastructure.Security
{
    public class PasswordHasherSettings
    {
        public string Key { get; set; }
    }
}